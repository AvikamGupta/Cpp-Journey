# 🚀 C++ Journey

> Mastering C++ — One Day at a Time.

Welcome! This repository documents my C++ learning journey through daily notes, code, and projects.

## Features
- 📚 Daily notes
- 💻 Practice programs
- 🚀 Projects
- 📈 Progress tracker
- 🎯 DSA preparation

## Structure
```text
CPP-Journey/
├── Notes/
├── Codes/
├── Projects/
└── README.md
```

## Progress
- ✅ Day 01 Basics
- ✅ Day 02 Variables, I/O & Operators
- ✅ Day 03 Conditionals
- ✅ Day 04 Loops
- ✅ Day 05 Patterns
- ✅ Day 06 Functions
- ✅ Day 07 Arrays
- ✅ Day 08 Vectors

## GitHub Stats
Replace `YOUR_USERNAME` with `AvikamGupta`.

```md
https://github-readme-stats.vercel.app/api?username=AvikamGupta&show_icons=true&theme=github_dark
```

---
### Author
**Avikam Gupta**

> *Code. Learn. Build. Repeat.*
